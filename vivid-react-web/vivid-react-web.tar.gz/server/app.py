from flask import Flask, request, jsonify, make_response
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import (
    JWTManager,
    create_access_token,
    jwt_required,
    get_jwt_identity,
)
from flask_cors import CORS
from flask_restful import Resource, Api
from datetime import timedelta

app = Flask(__name__)

CORS(
    app,
    supports_credentials=True,
    resources={r"/*": {"origins": "http://localhost:5173"}},
)

app.config["SECRET_KEY"] = "e5f6c1d6f8e9134b2246a4c7ea1a6f72"
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///site.db"
app.config["JWT_SECRET_KEY"] = "SECRET_KEY_qjwkdhjqhwdbqhwdq"

db = SQLAlchemy(app)
jwt = JWTManager(app)
api = Api(app)


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(60), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)


class Login(Resource):
    def post(self):
        data = request.get_json()
        email = data.get("email", "")
        password = data.get("password", "")
        remember = data.get("remember", False)

        user = User.query.filter_by(email=email).first()

        if user and user.password == password:
            expires = timedelta(days=7) if remember else timedelta(minutes=15)
            access_token = create_access_token(identity=user.id, expires_delta=expires)

            response = make_response(
                jsonify(
                    {
                        "message": "Login successful",
                        "access_token": access_token,
                        "user": {"username": user.username, "is_admin": user.is_admin},
                    }
                ),
                200,
            )

            return response

        return make_response(jsonify({"message": "Login failed"}), 401)


class Register(Resource):
    def post(self):
        data = request.get_json()
        username = data.get("username")
        email = data.get("email")
        password = data.get("password")

        # Check if the email already exists
        existing_user = User.query.filter_by(email=email).first()
        if not existing_user:
            user = User(username=username, email=email, password=password)
            db.session.add(user)
            db.session.commit()

            response = make_response(
                jsonify(
                    {
                        "message": "Registration was successful",
                    }
                ),
                200,
            )

            return response

        return make_response(jsonify({"message": "Registration failed"}), 401)


class UserData(Resource):
    @jwt_required()
    def get(self):
        user_id = get_jwt_identity()
        user = User.query.get(user_id)

        if user:
            user_data = {
                "username": user.username,
                "email": user.email,
                "is_admin": user.is_admin,
            }
            return jsonify(user_data)

        return make_response(jsonify({"message": "User not found"}), 404)


api.add_resource(Login, "/login")
api.add_resource(Register, "/register")
api.add_resource(UserData, "/user-data")

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)
