import { useState, useContext } from "react";
import { useMutation } from "@tanstack/react-query";
import AuthContext from "../AuthContext";
import axios from "axios";
import {
    Button,
    TextField,
    Checkbox,
    FormControlLabel,
    Box,
    Container,
    Typography,
    CssBaseline,
} from "@mui/material";
import { useNavigate } from "react-router-dom";

const Login = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [remember, setRemember] = useState(false);
    const { login } = useContext(AuthContext);
    const navigate = useNavigate();

    const mutation = useMutation({
        mutationFn: async ({ email, password, remember }) => {
            const response = await axios.post("http://localhost:5000/login", {
                email,
                password,
                remember,
            });
            return response.data;
        },
        onSuccess: (data) => {
            login(data.user, data.access_token);
        },
        onError: (error) => {
            alert("Login failed: " + error.message);
        },
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        mutation.mutate({ email, password, remember });
    };

    return (
        <Container component="main" maxWidth="xs">
            <CssBaseline />
            <Box
                sx={{
                    display: "flex",
                    justifyContent: "center",
                    minHeight: "100vh",
                    flexDirection: "column",
                    alignItems: "center",
                }}
            >
                <Typography component="h1" variant="h2">
                    Web App
                </Typography>
                <Box m={5}>
                    <img
                        src={
                            "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/React-icon.svg/1150px-React-icon.svg.png"
                        }
                        className="Logo"
                        alt="logo"
                        width={115}
                        height={100}
                    />
                </Box>
                <Box
                    component="form"
                    onSubmit={handleSubmit}
                    noValidate
                    sx={{ mt: 1 }}
                >
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="email"
                        label="Email Address"
                        name="email"
                        autoComplete="email"
                        autoFocus
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        name="password"
                        label="Password"
                        type="password"
                        id="password"
                        autoComplete="current-password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />
                    <FormControlLabel
                        control={
                            <Checkbox
                                value={remember}
                                color="primary"
                                checked={remember}
                                onChange={(e) => setRemember(e.target.checked)}
                            />
                        }
                        label="Remember me"
                    />
                    <Button
                        type="submit"
                        fullWidth
                        variant="contained"
                        sx={{ mt: 3, mb: 2 }}
                    >
                        Log In
                    </Button>
                    <Button
                        type="button"
                        fullWidth
                        variant="contained"
                        onClick={() => navigate("/register")}
                    >
                        Create Account
                    </Button>
                </Box>
            </Box>
        </Container>
    );
};

export default Login;
